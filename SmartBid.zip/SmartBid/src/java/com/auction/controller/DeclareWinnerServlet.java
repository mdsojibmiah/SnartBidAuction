package com.auction.controller;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.auction.util.DBConnection;

public class DeclareWinnerServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection conn = DBConnection.getConnection()) {

            String query = "SELECT p.id, p.seller_id, MAX(b.bid_amount) AS max_bid, b.buyer_id " +
                           "FROM products p JOIN bids b ON p.id = b.product_id " +
                           "WHERE p.status = 'approved' AND p.end_time <= NOW() " +
                           "GROUP BY p.id, p.seller_id";

            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int productId = rs.getInt("id");
                int sellerId = rs.getInt("seller_id");
                int buyerId = rs.getInt("buyer_id");
                double amount = rs.getDouble("max_bid");

                // 1. Minus from buyer wallet
                PreparedStatement ps1 = conn.prepareStatement("UPDATE buyer_wallet SET balance = balance - ? WHERE buyer_id = ?");
                ps1.setDouble(1, amount);
                ps1.setInt(2, buyerId);
                ps1.executeUpdate();

                // 2. Add to seller wallet
                PreparedStatement ps2 = conn.prepareStatement("UPDATE seller_wallet SET balance = balance + ? WHERE seller_id = ?");
                ps2.setDouble(1, amount);
                ps2.setInt(2, sellerId);
                ps2.executeUpdate();

                // 3. Mark product as 'sold'
                PreparedStatement ps3 = conn.prepareStatement("UPDATE products SET status = 'sold' WHERE id = ?");
                ps3.setInt(1, productId);
                ps3.executeUpdate();

                // 4. Insert winner entry (optional table)
                PreparedStatement ps4 = conn.prepareStatement("INSERT INTO winners (product_id, buyer_id, bid_amount) VALUES (?, ?, ?)");
                ps4.setInt(1, productId);
                ps4.setInt(2, buyerId);
                ps4.setDouble(3, amount);
                ps4.executeUpdate();
            }

            response.sendRedirect("winnerSuccess.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
