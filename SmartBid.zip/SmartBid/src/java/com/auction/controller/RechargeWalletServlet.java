package com.auction.controller;

import com.auction.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class RechargeWalletServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int uid = Integer.parseInt(request.getParameter("uid"));
        double amount = Double.parseDouble(request.getParameter("amount"));

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE users SET wallet = wallet + ? WHERE id = ?");
            ps.setDouble(1, amount);
            ps.setInt(2, uid);
            int i = ps.executeUpdate();

            if (i > 0) {
                response.sendRedirect("buyer/dashboard.jsp?msg=Wallet+recharged+successfully");
            } else {
                response.sendRedirect("buyer/recharge.jsp?error=Something+went+wrong");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("buyer/recharge.jsp?error=Exception+Occurred");
        }
    }
}
 