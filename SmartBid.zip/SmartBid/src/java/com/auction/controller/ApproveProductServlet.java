package com.auction.controller;

import com.auction.util.DBConnection;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ApproveProductServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String idParam = req.getParameter("id");
        String action = req.getParameter("action");

        if (idParam == null || action == null) {
            res.sendRedirect("admin/dashboard.jsp?msg=invalid_input");
            return;
        }

        int id = Integer.parseInt(idParam);
        String status;

        if ("approve".equalsIgnoreCase(action)) {
            status = "approved";
        } else if ("reject".equalsIgnoreCase(action)) {
            status = "rejected";
        } else {
            res.sendRedirect("admin/dashboard.jsp?msg=invalid_action");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE products SET status=? WHERE id=?");
            ps.setString(1, status);
            ps.setInt(2, id);
            int updated = ps.executeUpdate();

            if (updated > 0) {
                res.sendRedirect("admin/dashboard.jsp?msg=" + status);
            } else {
                res.sendRedirect("admin/dashboard.jsp?msg=update_failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("admin/dashboard.jsp?msg=exception");
        }
    }
}
