package com.auction.controller;

import com.auction.util.DBConnection;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM users WHERE email=? AND password=? AND status='active'");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("uid", rs.getInt("id"));
                session.setAttribute("role", rs.getString("role"));
                session.setAttribute("name", rs.getString("name"));

                String role = rs.getString("role");
                if (role.equals("admin")) res.sendRedirect("admin/dashboard.jsp");
                else if (role.equals("seller")) res.sendRedirect("seller/dashboard.jsp");
                else res.sendRedirect("buyer/dashboard.jsp");
            } else {
                res.sendRedirect("login.jsp?error=1");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
